# Flutter Onboarding UI

[YouTube Speed Code](https://www.youtube.com/watch?v=8eRQyE2PN7w)

[Design Credit](https://dribbble.com/shots/5965530-Communities-checklists-App-Onboarding-UI/attachments)
