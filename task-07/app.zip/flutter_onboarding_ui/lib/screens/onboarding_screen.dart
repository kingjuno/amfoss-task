import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dots_indicator/dots_indicator.dart';

class OnboardingScreen extends StatefulWidget {
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final double _numPages = 1;
  final PageController _pageController = PageController(initialPage: 0);
  double _currentPage = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 00.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Container(
                  height: 1000.0,
                  child: PageView(
                    physics: ClampingScrollPhysics(),
                    controller: _pageController,
                    onPageChanged: (int page) {
                      setState(() {
                        _currentPage = page.toDouble();
                      });
                    },
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.all(50.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Image.asset(
                                  'images/img1.png',
                                  width: 300.0,
                                  height: 300.0,
                                  alignment: Alignment.topLeft,
                                ),
                                Flexible(fit: FlexFit.tight, child: SizedBox()),
                                Image.asset(
                                  'images/img2.png',
                                  width: 200.0,
                                  height: 300.0,
                                  alignment: Alignment.bottomRight,
                                ),
                              ],
                            ),
                            SizedBox(height: 65.0),
                            Text('Hello!',
                                style: TextStyle(
                                  color: Color(0xFF6C29D0),
                                  fontSize: 25.0,
                                  fontWeight: FontWeight.bold,
                                )),
                            Text('Your own private Cloud is\none step away.',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 30.0,
                                  fontWeight: FontWeight.bold,
                                )),
                            SizedBox(height: 5.0),
                            Text('swipe left to get started.',
                                style: TextStyle(
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF6C29D0),
                                )),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(40.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Center(
                              child: Image(
                                image: AssetImage(
                                  'images/img3.png',
                                ),
                                height: 300.0,
                                width: 300.0,
                              ),
                            ),
                            SizedBox(height: 40.0),
                            Text('Your Premium Cloud',
                                style: TextStyle(
                                  color: Color(0xFF6C29D0),
                                  fontSize: 17.0,
                                  fontWeight: FontWeight.bold,
                                )),
                            SizedBox(height: 15.0),
                            Text(
                                'Launch your next\ncampaigns within minutes\nwith Cloud Campaign\nMonitor',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold,
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomSheet: (_currentPage == _numPages - 1 || _currentPage == _numPages)
          ? Container(
              height: 50.0,
              width: double.infinity,
              margin: EdgeInsets.all(25),
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: Color(0xFF6C29D0),
                  borderRadius: BorderRadius.circular(20.0),
                  border: Border.all(color: Color(0xFF6C29D0), width: 3.0)),
              child: Center(
                child: Padding(
                  padding: EdgeInsets.only(bottom: 00.0),
                  child: Text(
                    'Create an account',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            )
          : Text('hola'),
    );
  }
}
